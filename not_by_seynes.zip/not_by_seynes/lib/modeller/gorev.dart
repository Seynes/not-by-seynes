import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// Görevin öncelik derecesi
enum Oncelik {
  dusuk,
  orta,
  yuksek;

  String get metin {
    switch (this) {
      case Oncelik.dusuk:
        return 'Düşük';
      case Oncelik.orta:
        return 'Orta';
      case Oncelik.yuksek:
        return 'Yüksek';
    }
  }

  Color get renk {
    switch (this) {
      case Oncelik.dusuk:
        return const Color(0xFF10B981); // Yeşil
      case Oncelik.orta:
        return const Color(0xFFF59E0B); // Turuncu
      case Oncelik.yuksek:
        return const Color(0xFFEF4444); // Kırmızı
    }
  }
}

/// Görev Kategori Tanımı
enum Kategori {
  is_,
  kisisel,
  egitim,
  alisveris,
  saglik,
  diger;

  String get metin {
    switch (this) {
      case Kategori.is_:
        return 'İş';
      case Kategori.kisisel:
        return 'Kişisel';
      case Kategori.egitim:
        return 'Eğitim';
      case Kategori.alisveris:
        return 'Alışveriş';
      case Kategori.saglik:
        return 'Sağlık';
      case Kategori.diger:
        return 'Diğer';
    }
  }

  IconData get ikon {
    switch (this) {
      case Kategori.is_:
        return Icons.work_outline_rounded;
      case Kategori.kisisel:
        return Icons.person_outline_rounded;
      case Kategori.egitim:
        return Icons.school_outlined;
      case Kategori.alisveris:
        return Icons.shopping_bag_outlined;
      case Kategori.saglik:
        return Icons.fitness_center_rounded;
      case Kategori.diger:
        return Icons.category_outlined;
    }
  }

  /// Kategoriye özgü canlı renk tanımı (Chips ve kartlar için)
  Color get renk {
    switch (this) {
      case Kategori.is_:
        return const Color(0xFF2563EB); // Canlı Mavi
      case Kategori.kisisel:
        return const Color(0xFF7C3AED); // Mor / Menekşe
      case Kategori.egitim:
        return const Color(0xFF059669); // Zümrüt Yeşili
      case Kategori.alisveris:
        return const Color(0xFFD97706); // Kehribar / Turuncu
      case Kategori.saglik:
        return const Color(0xFFE11D48); // Gül / Mercan
      case Kategori.diger:
        return const Color(0xFF0891B2); // Camgöbeği
    }
  }

  Color get acikRenk => renk.withValues(alpha: 0.12);
  Color get kenarlikRengi => renk.withValues(alpha: 0.35);
}

/// Görev Model Sınıfı
class Gorev {
  final String id;
  final String baslik;
  final String aciklama;
  final bool tamamlandiMi;
  final DateTime olusturulmaTarihi;
  final DateTime? sonTarih;
  final Oncelik oncelik;
  final Kategori kategori;

  const Gorev({
    required this.id,
    required this.baslik,
    this.aciklama = '',
    this.tamamlandiMi = false,
    required this.olusturulmaTarihi,
    this.sonTarih,
    this.oncelik = Oncelik.orta,
    this.kategori = Kategori.kisisel,
  });

  /// Değiştirilmiş yeni kopya oluşturma (Immutability desteği)
  Gorev copyWith({
    String? id,
    String? baslik,
    String? aciklama,
    bool? tamamlandiMi,
    DateTime? olusturulmaTarihi,
    DateTime? sonTarih,
    Oncelik? oncelik,
    Kategori? kategori,
    bool sonTarihiTemizle = false,
  }) {
    return Gorev(
      id: id ?? this.id,
      baslik: baslik ?? this.baslik,
      aciklama: aciklama ?? this.aciklama,
      tamamlandiMi: tamamlandiMi ?? this.tamamlandiMi,
      olusturulmaTarihi: olusturulmaTarihi ?? this.olusturulmaTarihi,
      sonTarih: sonTarihiTemizle ? null : (sonTarih ?? this.sonTarih),
      oncelik: oncelik ?? this.oncelik,
      kategori: kategori ?? this.kategori,
    );
  }

  /// JSON dönüşümü (SharedPreferences için)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'baslik': baslik,
      'aciklama': aciklama,
      'tamamlandiMi': tamamlandiMi,
      'olusturulmaTarihi': olusturulmaTarihi.toIso8601String(),
      'sonTarih': sonTarih?.toIso8601String(),
      'oncelik': oncelik.name,
      'kategori': kategori.name,
    };
  }

  /// JSON verisinden Gorev nesnesi üretme
  factory Gorev.fromJson(Map<String, dynamic> json) {
    return Gorev(
      id: json['id'] as String,
      baslik: json['baslik'] as String,
      aciklama: (json['aciklama'] as String?) ?? '',
      tamamlandiMi: (json['tamamlandiMi'] as bool?) ?? false,
      olusturulmaTarihi: DateTime.parse(json['olusturulmaTarihi'] as String),
      sonTarih: json['sonTarih'] != null
          ? DateTime.parse(json['sonTarih'] as String)
          : null,
      oncelik: Oncelik.values.firstWhere(
        (e) => e.name == json['oncelik'],
        orElse: () => Oncelik.orta,
      ),
      kategori: Kategori.values.firstWhere(
        (e) => e.name == json['kategori'],
        orElse: () => Kategori.kisisel,
      ),
    );
  }

  /// Biçimlendirilmiş son tarih gösterimi
  String? get bicimlendirilmisSonTarih {
    if (sonTarih == null) return null;
    return DateFormat('d MMM yyyy', 'tr_TR').format(sonTarih!);
  }

  /// Görevin süresi geçti mi kontrolü
  bool get sureGectiMi {
    if (sonTarih == null || tamamlandiMi) return false;
    return DateTime.now().isAfter(sonTarih!);
  }
}
