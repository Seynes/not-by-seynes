import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../modeller/gorev.dart';

class DepolamaServisi {
  static const String _gorevlerAnahtari = 'kayitli_gorevler_v1';

  // Singleton Tasarım Kalıbı
  static final DepolamaServisi _ornek = DepolamaServisi._dahili();
  factory DepolamaServisi() => _ornek;
  DepolamaServisi._dahili();

  /// Tüm kayıtlı görevleri SharedPreferences üzerinden getirir
  Future<List<Gorev>> gorevleriGetir() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonMetni = prefs.getString(_gorevlerAnahtari);

      if (jsonMetni == null || jsonMetni.isEmpty) {
        // İlk açılışta varsayılan demo görevleri yükle
        final varsayilanlar = _varsayilanGorevleriOlustur();
        await gorevleriKaydet(varsayilanlar);
        return varsayilanlar;
      }

      final List<dynamic> cozulenListe = jsonDecode(jsonMetni) as List<dynamic>;
      return cozulenListe
          .map((item) => Gorev.fromJson(item as Map<String, dynamic>))
          .toList();
    } catch (e) {
      // Hata durumunda boş liste dön
      return [];
    }
  }

  /// Görevler listesini JSON formatına çevirip kalıcı hafızaya yazar
  Future<bool> gorevleriKaydet(List<Gorev> gorevler) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<Map<String, dynamic>> haritaListesi =
          gorevler.map((g) => g.toJson()).toList();
      final jsonMetni = jsonEncode(haritaListesi);
      return await prefs.setString(_gorevlerAnahtari, jsonMetni);
    } catch (e) {
      return false;
    }
  }

  /// Tek bir görevi listeye ekler ve kaydeder
  Future<List<Gorev>> gorevEkle(Gorev yeniGorev) async {
    final mevcut = await gorevleriGetir();
    final guncel = [yeniGorev, ...mevcut];
    await gorevleriKaydet(guncel);
    return guncel;
  }

  /// Mevcut görevin bilgilerini günceller
  Future<List<Gorev>> gorevGuncelle(Gorev guncellenmisGorev) async {
    final mevcut = await gorevleriGetir();
    final guncel = mevcut.map((g) {
      return g.id == guncellenmisGorev.id ? guncellenmisGorev : g;
    }).toList();
    await gorevleriKaydet(guncel);
    return guncel;
  }

  /// ID değerine göre görevi siler
  Future<List<Gorev>> gorevSil(String id) async {
    final mevcut = await gorevleriGetir();
    final guncel = mevcut.where((g) => g.id != id).toList();
    await gorevleriKaydet(guncel);
    return guncel;
  }

  /// Görevin tamamlandı/tamamlanmadı durumunu tersine çevirir
  Future<List<Gorev>> gorevDurumuDegistir(String id) async {
    final mevcut = await gorevleriGetir();
    final guncel = mevcut.map((g) {
      if (g.id == id) {
        return g.copyWith(tamamlandiMi: !g.tamamlandiMi);
      }
      return g;
    }).toList();
    await gorevleriKaydet(guncel);
    return guncel;
  }

  /// İlk kurulum için örnek başlangıç görevleri
  List<Gorev> _varsayilanGorevleriOlustur() {
    final simdi = DateTime.now();
    return [
      Gorev(
        id: '1',
        baslik: 'Flutter projesini derle ve test et',
        aciklama: 'flutter run komutu ile Android/iOS emülatörlerinde performansı gözlemle.',
        tamamlandiMi: false,
        olusturulmaTarihi: simdi.subtract(const Duration(days: 2)),
        sonTarih: simdi.add(const Duration(days: 1)),
        oncelik: Oncelik.yuksek,
        kategori: Kategori.is_,
      ),
      Gorev(
        id: '2',
        baslik: 'SharedPreferences depolama servisini bağla',
        aciklama: 'Verilerin cihaz hafızasında kalıcı olarak saklanması.',
        tamamlandiMi: true,
        olusturulmaTarihi: simdi.subtract(const Duration(days: 3)),
        sonTarih: simdi.subtract(const Duration(days: 1)),
        oncelik: Oncelik.yuksek,
        kategori: Kategori.is_,
      ),
      Gorev(
        id: '3',
        baslik: 'Haftalık market alışverişi listesi',
        aciklama: 'Süt, organik yumurta, filtre kahve ve tam buğday ekmeği.',
        tamamlandiMi: false,
        olusturulmaTarihi: simdi.subtract(const Duration(hours: 12)),
        sonTarih: simdi.add(const Duration(days: 2)),
        oncelik: Oncelik.orta,
        kategori: Kategori.alisveris,
      ),
      Gorev(
        id: '4',
        baslik: '30 dakika açık hava tempolu yürüyüş',
        aciklama: 'Günün yorgunluğunu atmak için sahil yolunda yürüyüş.',
        tamamlandiMi: false,
        olusturulmaTarihi: simdi.subtract(const Duration(hours: 4)),
        sonTarih: simdi.add(const Duration(hours: 8)),
        oncelik: Oncelik.dusuk,
        kategori: Kategori.saglik,
      ),
    ];
  }
}
