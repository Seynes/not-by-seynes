/// Türkçe'ye uygun küçük harfe çevirme (İ→i, I→ı).
/// Dart'ın varsayılan toLowerCase() fonksiyonu "İ" harfini yanlış çevirir.
String trKucuk(String metin) {
  return metin.replaceAll('İ', 'i').replaceAll('I', 'ı').toLowerCase();
}

/// Metnin ilk harfini Türkçe kurallarına göre büyütür.
String ilkHarfiBuyut(String metin) {
  final temiz = metin.trim();
  if (temiz.isEmpty) return temiz;
  final ilk = temiz[0];
  final buyuk = ilk == 'i'
      ? 'İ'
      : ilk == 'ı'
          ? 'I'
          : ilk.toUpperCase();
  return buyuk + temiz.substring(1);
}
