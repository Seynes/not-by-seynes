import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../modeller/gorev.dart';
import '../servisler/depolama_servisi.dart';
import '../yardimcilar/metin.dart';

class GorevListesiEkrani extends StatefulWidget {
  const GorevListesiEkrani({super.key});

  @override
  State<GorevListesiEkrani> createState() => _GorevListesiEkraniState();
}

enum FiltreSecenegi { tumu, aktif, tamamlanan }

class _GorevListesiEkraniState extends State<GorevListesiEkrani> {
  final DepolamaServisi _depolamaServisi = DepolamaServisi();
  final TextEditingController _aramaController = TextEditingController();
  late stt.SpeechToText _speech;
  bool _speechHazir = false;

  List<Gorev> _tumGorevler = [];
  bool _yukleniyor = true;
  String _aramaMetni = '';
  FiltreSecenegi _seciliFiltre = FiltreSecenegi.tumu;
  Kategori? _seciliKategori;

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _gorevleriYukle();
  }

  /// Ses tanıma ilk kullanımda başlatılır (izin de o zaman istenir).
  Future<bool> _sesHazirla() async {
    if (_speechHazir) return true;
    _speechHazir = await _speech.initialize(
      onError: (val) => debugPrint('Ses hatası: $val'),
      onStatus: (val) => debugPrint('Ses durumu: $val'),
    );
    if (!_speechHazir && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Mikrofon kullanılamıyor. Uygulama izinlerini kontrol edin.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
    return _speechHazir;
  }

  @override
  void dispose() {
    _aramaController.dispose();
    _speech.cancel();
    super.dispose();
  }

  Future<void> _gorevleriYukle() async {
    setState(() => _yukleniyor = true);
    final liste = await _depolamaServisi.gorevleriGetir();
    if (!mounted) return;
    setState(() {
      _tumGorevler = liste;
      _yukleniyor = false;
    });
  }

  List<Gorev> get _filtrelenmisGorevler {
    return _tumGorevler.where((gorev) {
      // Durum filtresi
      if (_seciliFiltre == FiltreSecenegi.aktif && gorev.tamamlandiMi) {
        return false;
      }
      if (_seciliFiltre == FiltreSecenegi.tamamlanan && !gorev.tamamlandiMi) {
        return false;
      }

      // Kategori filtresi
      if (_seciliKategori != null && gorev.kategori != _seciliKategori) {
        return false;
      }

      // Anlık Arama filtresi (Görev başlıkları ve kategoriler arasında arama)
      if (_aramaMetni.isNotEmpty) {
        final arama = trKucuk(_aramaMetni);
        final baslikUyuyor = trKucuk(gorev.baslik).contains(arama);
        final kategoriUyuyor = trKucuk(gorev.kategori.metin).contains(arama);
        final aciklamaUyuyor = trKucuk(gorev.aciklama).contains(arama);
        return baslikUyuyor || kategoriUyuyor || aciklamaUyuyor;
      }

      return true;
    }).toList();
  }

  Future<void> _kaydet() => _depolamaServisi.gorevleriKaydet(_tumGorevler);

  void _gorevDurumuDegistir(Gorev gorev) {
    final index = _tumGorevler.indexWhere((g) => g.id == gorev.id);
    if (index == -1) return;
    final yeniDurum = !_tumGorevler[index].tamamlandiMi;

    setState(() {
      _tumGorevler[index] = _tumGorevler[index].copyWith(tamamlandiMi: yeniDurum);
    });
    _kaydet();

    if (yeniDurum) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text('🎉 "${gorev.baslik}" tamamlandı!'),
            duration: const Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
          ),
        );
    }
  }

  /// Önce listeden çıkarılır (Dismissible bunu aynı karede ister), sonra kaydedilir.
  void _gorevSil(Gorev gorev) {
    final index = _tumGorevler.indexWhere((g) => g.id == gorev.id);
    if (index == -1) return;

    setState(() => _tumGorevler.removeAt(index));
    _kaydet();

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text('"${gorev.baslik}" silindi'),
          action: SnackBarAction(
            label: 'Geri Al',
            onPressed: () {
              if (!mounted) return;
              setState(() {
                _tumGorevler.insert(index.clamp(0, _tumGorevler.length), gorev);
              });
              _kaydet();
            },
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  /// Sesli Komutla Görev Ekleme Diyaloğu ve İşleyicisi (Speech-to-Text)
  void _sesleGorevEkleDialog() {
    String sesMetni = '';
    bool dinleniyor = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final tema = Theme.of(context);
            return Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: tema.colorScheme.surface,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Sesle Görev Ekle 🎙️', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(
                    dinleniyor ? 'Sizi dinliyorum, konuşun...' : 'Mikrofona dokunun ve görevinizi sesli söyleyin',
                    style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () async {
                      if (dinleniyor) {
                        await _speech.stop();
                        setModalState(() => dinleniyor = false);
                      } else if (await _sesHazirla()) {
                        setModalState(() => dinleniyor = true);
                        await _speech.listen(
                          onResult: (res) {
                            setModalState(() => sesMetni = res.recognizedWords);
                          },
                          localeId: 'tr_TR',
                        );
                      }
                    },
                    child: CircleAvatar(
                      radius: 36,
                      backgroundColor: dinleniyor ? Colors.red : const Color(0xFFF43F5E),
                      child: Icon(dinleniyor ? Icons.mic : Icons.mic_none, color: Colors.white, size: 36),
                    ),
                  ),
                  if (sesMetni.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text('"$sesMetni"', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      icon: const Icon(Icons.check_rounded),
                      label: const Text('Görevi Onayla ve Ekle'),
                      onPressed: () async {
                        final kucuk = trKucuk(sesMetni);
                        Oncelik oncelik = kucuk.contains('acil') || kucuk.contains('yüksek') ? Oncelik.yuksek : Oncelik.orta;
                        Kategori kategori = kucuk.contains('market') || kucuk.contains('alışveriş') ? Kategori.alisveris :
                                           kucuk.contains('sağlık') || kucuk.contains('spor') ? Kategori.saglik :
                                           kucuk.contains('ders') || kucuk.contains('eğitim') ? Kategori.egitim : Kategori.diger;
                        
                        final yeni = Gorev(
                          id: const Uuid().v4(),
                          baslik: ilkHarfiBuyut(sesMetni),
                          aciklama: '',
                          oncelik: oncelik,
                          kategori: kategori,
                          olusturulmaTarihi: DateTime.now(),
                        );
                        setState(() => _tumGorevler.insert(0, yeni));
                        _kaydet();
                        Navigator.pop(ctx);
                        if (!mounted) return;
                        ScaffoldMessenger.of(this.context).showSnackBar(
                          SnackBar(content: Text('🎉 "$sesMetni" sesle eklendi!'), behavior: SnackBarBehavior.floating),
                        );
                      },
                    ),
                  ],
                ],
              ),
            );
          },
        );
      },
    ).whenComplete(() => _speech.stop());
  }

  void _gorevEkleDuzenleDialog({Gorev? duzenlenecekGorev}) {
    final baslikController =
        TextEditingController(text: duzenlenecekGorev?.baslik ?? '');
    final aciklamaController =
        TextEditingController(text: duzenlenecekGorev?.aciklama ?? '');
    Oncelik seciliOncelik = duzenlenecekGorev?.oncelik ?? Oncelik.orta;
    Kategori seciliKategori = duzenlenecekGorev?.kategori ?? Kategori.kisisel;
    DateTime? seciliTarih = duzenlenecekGorev?.sonTarih;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final tema = Theme.of(context);
            return Container(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              decoration: BoxDecoration(
                color: tema.colorScheme.surface,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.withValues(alpha: 0.3),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      duzenlenecekGorev == null ? 'Yeni Görev Oluştur' : 'Görevi Düzenle',
                      style: tema.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Başlık Alanı (Sesli Yazma Desteği ile)
                    TextField(
                      controller: baslikController,
                      autofocus: duzenlenecekGorev == null,
                      decoration: InputDecoration(
                        labelText: 'Görev Başlığı *',
                        hintText: 'Örn: Raporu hazırla',
                        filled: true,
                        fillColor: tema.scaffoldBackgroundColor,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _speech.isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
                            color: _speech.isListening ? Colors.red : Colors.indigo,
                          ),
                          tooltip: 'Sesle Dikte Et (Speech-to-Text)',
                          onPressed: () async {
                            if (_speech.isListening) {
                              await _speech.stop();
                              setModalState(() {});
                            } else if (await _sesHazirla()) {
                              await _speech.listen(
                                onResult: (res) {
                                  setModalState(() {
                                    baslikController.text = res.recognizedWords;
                                  });
                                },
                                localeId: 'tr_TR',
                              );
                              setModalState(() {});
                            }
                          },
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Açıklama Alanı (Sesli Yazma Desteği ile)
                    TextField(
                      controller: aciklamaController,
                      maxLines: 2,
                      decoration: InputDecoration(
                        labelText: 'Açıklama (İsteğe bağlı)',
                        filled: true,
                        fillColor: tema.scaffoldBackgroundColor,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _speech.isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
                            color: _speech.isListening ? Colors.red : Colors.indigo,
                          ),
                          tooltip: 'Sesle Dikte Et (Speech-to-Text)',
                          onPressed: () async {
                            if (_speech.isListening) {
                              await _speech.stop();
                              setModalState(() {});
                            } else if (await _sesHazirla()) {
                              await _speech.listen(
                                onResult: (res) {
                                  setModalState(() {
                                    aciklamaController.text = res.recognizedWords;
                                  });
                                },
                                localeId: 'tr_TR',
                              );
                              setModalState(() {});
                            }
                          },
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Öncelik Seçimi
                    Text(
                      'Öncelik Derecesi',
                      style: tema.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    SegmentedButton<Oncelik>(
                      segments: Oncelik.values.map((o) {
                        return ButtonSegment(
                          value: o,
                          label: Text(o.metin),
                          icon: Icon(Icons.circle, size: 10, color: o.renk),
                        );
                      }).toList(),
                      selected: {seciliOncelik},
                      onSelectionChanged: (yeni) {
                        setModalState(() => seciliOncelik = yeni.first);
                      },
                    ),
                    const SizedBox(height: 16),

                    // Kategori Seçimi
                    Text(
                      'Kategori',
                      style: tema.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: Kategori.values.map((kat) {
                        final secili = seciliKategori == kat;
                        return ChoiceChip(
                          avatar: Icon(kat.ikon, size: 16),
                          label: Text(kat.metin),
                          selected: secili,
                          onSelected: (_) {
                            setModalState(() => seciliKategori = kat);
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 16),

                    // Tarih Seçici Butonu
                    OutlinedButton.icon(
                      icon: const Icon(Icons.calendar_today_rounded),
                      label: Text(
                        seciliTarih == null
                            ? 'Bitiş Tarihi Seç'
                            : 'Bitiş: ${seciliTarih!.day}/${seciliTarih!.month}/${seciliTarih!.year}',
                      ),
                      onPressed: () async {
                        final secilen = await showDatePicker(
                          context: context,
                          initialDate: seciliTarih ?? DateTime.now(),
                          firstDate: DateTime(2020),
                          lastDate: DateTime.now().add(const Duration(days: 1825)),
                        );
                        if (secilen != null) {
                          setModalState(() {
                            // Gün sonu: seçilen gün bitene kadar "süresi geçti" sayılmaz.
                            seciliTarih = DateTime(secilen.year, secilen.month, secilen.day, 23, 59);
                          });
                        }
                      },
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    if (seciliTarih != null)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () => setModalState(() => seciliTarih = null),
                          child: const Text('Tarihi Kaldır'),
                        ),
                      ),
                    const SizedBox(height: 24),

                    // Kaydet Butonu
                    FilledButton(
                      onPressed: () async {
                        if (baslikController.text.trim().isEmpty) return;

                        if (duzenlenecekGorev == null) {
                          // Yeni Ekle
                          final yeni = Gorev(
                            id: const Uuid().v4(),
                            baslik: baslikController.text.trim(),
                            aciklama: aciklamaController.text.trim(),
                            oncelik: seciliOncelik,
                            kategori: seciliKategori,
                            sonTarih: seciliTarih,
                            olusturulmaTarihi: DateTime.now(),
                          );
                          setState(() => _tumGorevler.insert(0, yeni));
                        } else {
                          // Güncelle
                          final guncel = duzenlenecekGorev.copyWith(
                            baslik: baslikController.text.trim(),
                            aciklama: aciklamaController.text.trim(),
                            oncelik: seciliOncelik,
                            kategori: seciliKategori,
                            sonTarih: seciliTarih,
                            sonTarihiTemizle: seciliTarih == null,
                          );
                          setState(() {
                            final i = _tumGorevler.indexWhere((g) => g.id == guncel.id);
                            if (i != -1) _tumGorevler[i] = guncel;
                          });
                        }
                        await _kaydet();
                        if (ctx.mounted) Navigator.pop(ctx);
                      },
                      style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: Text(
                        duzenlenecekGorev == null ? 'Görevi Kaydet' : 'Değişiklikleri Kaydet',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() => _speech.stop());
  }

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    final tamamlananSayisi = _tumGorevler.where((g) => g.tamamlandiMi).length;
    final toplamSayisi = _tumGorevler.length;
    final yuzde = toplamSayisi == 0 ? 0.0 : tamamlananSayisi / toplamSayisi;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Not by Seynes 📋',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 24),
            ),
            Text(
              'Toplam $toplamSayisi görevden $tamamlananSayisi tamamlandı',
              style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Yenile',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _gorevleriYukle,
          ),
        ],
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // İlerleme Çubuğu ve Kartı
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF4F46E5), Color(0xFF7C3AED)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF4F46E5).withValues(alpha: 0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Tamamlanma Oranı',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              '% ${(yuzde * 100).toInt()}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 18,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            value: yuzde,
                            minHeight: 8,
                            backgroundColor: Colors.white24,
                            valueColor: const AlwaysStoppedAnimation(Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Anlık Arama Kutusu (Başlık ve Kategori Arama)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: TextField(
                    controller: _aramaController,
                    onChanged: (deger) => setState(() => _aramaMetni = deger),
                    decoration: InputDecoration(
                      hintText: 'Görev başlığı veya kategori ara...',
                      prefixIcon: const Icon(Icons.search_rounded),
                      suffixIcon: _aramaMetni.isNotEmpty
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  margin: const EdgeInsets.only(right: 4),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF6366F1).withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    '${_filtrelenmisGorevler.length} sonuç',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF4F46E5),
                                    ),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.clear_rounded, size: 18),
                                  onPressed: () {
                                    _aramaController.clear();
                                    setState(() => _aramaMetni = '');
                                  },
                                ),
                              ],
                            )
                          : null,
                      filled: true,
                      fillColor: tema.brightness == Brightness.dark
                          ? tema.colorScheme.surfaceContainerHighest
                          : Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),

                // Filtreleme Çipleri
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: Row(
                    children: [
                      FilterChip(
                        label: Text('Tümü ($toplamSayisi)'),
                        selected: _seciliFiltre == FiltreSecenegi.tumu && _seciliKategori == null,
                        onSelected: (_) {
                          setState(() {
                            _seciliFiltre = FiltreSecenegi.tumu;
                            _seciliKategori = null;
                          });
                        },
                      ),
                      const SizedBox(width: 8),
                      FilterChip(
                        label: Text('Aktif (${toplamSayisi - tamamlananSayisi})'),
                        selected: _seciliFiltre == FiltreSecenegi.aktif,
                        onSelected: (_) => setState(() => _seciliFiltre = FiltreSecenegi.aktif),
                      ),
                      const SizedBox(width: 8),
                      FilterChip(
                        label: Text('Tamamlanan ($tamamlananSayisi)'),
                        selected: _seciliFiltre == FiltreSecenegi.tamamlanan,
                        onSelected: (_) => setState(() => _seciliFiltre = FiltreSecenegi.tamamlanan),
                      ),
                      const VerticalDivider(width: 20),
                      ...Kategori.values.map((k) {
                        final secili = _seciliKategori == k;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: FilterChip(
                            avatar: Icon(
                              k.ikon,
                              size: 14,
                              color: secili ? Colors.white : k.renk,
                            ),
                            label: Text(k.metin),
                            selected: secili,
                            selectedColor: k.renk,
                            backgroundColor: k.acikRenk,
                            side: BorderSide(color: k.kenarlikRengi),
                            labelStyle: TextStyle(
                              color: secili ? Colors.white : k.renk,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                            onSelected: (aktif) {
                              setState(() => _seciliKategori = aktif ? k : null);
                            },
                          ),
                        );
                      }),
                    ],
                  ),
                ),

                // Görev Listesi
                Expanded(
                  child: _filtrelenmisGorevler.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.task_alt_rounded, size: 64, color: Colors.grey.shade400),
                              const SizedBox(height: 12),
                              Text(
                                'Henüz bir görev bulunamadı',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                          itemCount: _filtrelenmisGorevler.length,
                          itemBuilder: (context, index) {
                            final gorev = _filtrelenmisGorevler[index];
                            return Dismissible(
                              key: Key(gorev.id),
                              direction: DismissDirection.endToStart,
                              background: Container(
                                alignment: Alignment.centerRight,
                                padding: const EdgeInsets.only(right: 20),
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.red.shade400,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: const Icon(Icons.delete_outline_rounded, color: Colors.white),
                              ),
                              onDismissed: (_) => _gorevSil(gorev),
                              child: Card(
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  side: BorderSide(color: gorev.kategori.renk.withValues(alpha: 0.55), width: 1.5),
                                ),
                                child: ListTile(
                                  onTap: () => _gorevEkleDuzenleDialog(duzenlenecekGorev: gorev),
                                  leading: Checkbox(
                                    value: gorev.tamamlandiMi,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    onChanged: (_) => _gorevDurumuDegistir(gorev),
                                  ),
                                  title: Text(
                                    gorev.baslik,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      decoration: gorev.tamamlandiMi
                                          ? TextDecoration.lineThrough
                                          : TextDecoration.none,
                                      color: gorev.tamamlandiMi
                                          ? Colors.grey.shade500
                                          : null,
                                    ),
                                  ),
                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      if (gorev.aciklama.isNotEmpty)
                                        Padding(
                                          padding: const EdgeInsets.only(top: 4),
                                          child: Text(
                                            gorev.aciklama,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                                          ),
                                        ),
                                      const SizedBox(height: 6),
                                      Row(
                                        children: [
                                          // Kategoriye Özgü Renkli Etiket (Colored Chip)
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: gorev.kategori.acikRenk,
                                              border: Border.all(color: gorev.kategori.kenarlikRengi),
                                              borderRadius: BorderRadius.circular(6),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(gorev.kategori.ikon, size: 12, color: gorev.kategori.renk),
                                                const SizedBox(width: 4),
                                                Text(
                                                  gorev.kategori.metin,
                                                  style: TextStyle(
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.bold,
                                                    color: gorev.kategori.renk,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          // Öncelik Rozeti
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: gorev.oncelik.renk.withValues(alpha: 0.15),
                                              borderRadius: BorderRadius.circular(6),
                                            ),
                                            child: Text(
                                              gorev.oncelik.metin,
                                              style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.bold,
                                                color: gorev.oncelik.renk,
                                              ),
                                            ),
                                          ),
                                          if (gorev.bicimlendirilmisSonTarih != null) ...[
                                            const SizedBox(width: 8),
                                            Icon(
                                              Icons.access_time_rounded,
                                              size: 12,
                                              color: gorev.sureGectiMi ? Colors.red : Colors.grey,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              gorev.bicimlendirilmisSonTarih!,
                                              style: TextStyle(
                                                fontSize: 11,
                                                color: gorev.sureGectiMi ? Colors.red : Colors.grey.shade600,
                                                fontWeight: gorev.sureGectiMi ? FontWeight.bold : FontWeight.normal,
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ],
                                  ),
                                  trailing: IconButton(
                                    icon: const Icon(Icons.delete_outline_rounded, color: Colors.grey),
                                    onPressed: () => _gorevSil(gorev),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.extended(
            heroTag: 'sesleEkleBtn',
            backgroundColor: const Color(0xFFF43F5E),
            onPressed: _sesleGorevEkleDialog,
            icon: const Icon(Icons.mic_rounded, color: Colors.white),
            label: const Text('Sesle Ekle', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
          ),
          const SizedBox(width: 10),
          FloatingActionButton.extended(
            heroTag: 'yeniGorevBtn',
            onPressed: () => _gorevEkleDuzenleDialog(),
            icon: const Icon(Icons.add_rounded),
            label: const Text('Yeni Görev', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}
