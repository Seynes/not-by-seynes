# Not by Seynes (Flutter & Dart)

Türkçe arayüzlü, yerel veri saklayan görev listesi uygulaması.

## Özellikler
- Görev ekleme, düzenleme, silme (kaydırarak veya çöp kutusu) ve "Geri Al"
- Öncelik (Düşük/Orta/Yüksek), kategori, bitiş tarihi ve süresi geçen görev uyarısı
- Türkçe uyumlu canlı arama, durum ve kategori filtreleri (sayaçlı)
- Tamamlanma oranı kartı
- Sesle görev ekleme / dikte (speech_to_text)
- Açık/koyu tema (sistem temasına uyar)
- shared_preferences ile kalıcı yerel saklama

## Kurulum (önemli)
Bu klasörde yalnızca `lib/` ve `pubspec.yaml` var; Android/iOS klasörleri yok.

```bash
flutter create not_by_seynes
# Bu zip'teki lib/ klasörünü ve pubspec.yaml dosyasını yeni projenin üzerine kopyalayın
cd not_by_seynes
flutter pub get
flutter run
```

Flutter 3.27 veya daha yeni bir sürüm gerekir (`flutter upgrade`).

## Telefonda görünen uygulama adı
Proje oluşturduktan sonra (Linux/macOS/Git Bash):
```bash
sed -i 's/android:label="[^"]*"/android:label="Not by Seynes"/' android/app/src/main/AndroidManifest.xml
```
Windows'ta bu dosyayı açıp `android:label="Not by Seynes"` olarak elle değiştirin.

## Mikrofon izinleri (sesle ekleme için)

**Android** — `android/app/src/main/AndroidManifest.xml`, `<manifest>` etiketinin içine:
```xml
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.INTERNET"/>
<queries>
    <intent>
        <action android:name="android.speech.RecognitionService"/>
    </intent>
</queries>
```
Derleme "minSdkVersion" hatası verirse `android/app/build.gradle` içinde minSdk değerini 24 yapın.

**iOS** — `ios/Runner/Info.plist`, `<dict>` içine:
```xml
<key>NSMicrophoneUsageDescription</key>
<string>Görevleri sesle eklemek için mikrofon gerekir.</string>
<key>NSSpeechRecognitionUsageDescription</key>
<string>Konuşmanızı metne çevirmek için konuşma tanıma gerekir.</string>
```

## Proje yapısı
```
lib/
├── main.dart
├── modeller/gorev.dart
├── servisler/depolama_servisi.dart
├── yardimcilar/metin.dart        (Türkçe küçük/büyük harf yardımcıları)
└── ekranlar/gorev_listesi_ekrani.dart
```

## Bu sürümde yapılan düzeltmeler
- Kaydırarak silmede oluşan "dismissed Dismissible" hatası giderildi
- Türkçe aramada "İ/I" sorunu düzeltildi ("iş" artık İş kategorisini bulur)
- Bitiş tarihi gün sonuna ayarlandı; tarih artık kaldırılabiliyor
- Koyu temada okunmayan arama kutusu düzeltildi
- Listenin son kartı butonların altında kalmıyor
- Mikrofon izni açılışta değil ilk kullanımda isteniyor; kullanılmayan permission_handler kaldırıldı
- intl sürümü esnetildi, CardThemeData ve withValues ile yeni Flutter sürümlerine uyum sağlandı
